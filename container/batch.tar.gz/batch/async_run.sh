#!/bin/sh


ASYNC_STOP_FILE=/mnt/nfs/STOPFILE

java -cp "lib/*:target/*" -DASYNC_STOP_FILE=${ASYNC_STOP_FILE} org.terasoluna.batch.async.db.AsyncBatchDaemon


