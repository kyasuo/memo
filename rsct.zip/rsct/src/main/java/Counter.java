import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Count;
import bean.Diff;
import bean.FileMapping;
import util.Utils;

public class Counter {

	private static final String TMPDIR = System.getProperty("java.io.tmpdir");

	public static void main(String[] args) throws Exception {

		if (args.length != 1) {
			System.err.println("Usage: java Counter [input file(csv)]");
			System.exit(1);
		}

		Path tempPath = Files.createTempDirectory(Paths.get(TMPDIR), "_comp" + System.currentTimeMillis());
		Path oldPath = Files.createDirectory(Paths.get(tempPath.toString(), "old"));
		Path newPath = Files.createDirectory(Paths.get(tempPath.toString(), "new"));

		List<FileMapping> mappings = new ArrayList<FileMapping>();
		FileMapping fm;
		String[] values;
		int number = 0;
		for (String line : Files.readAllLines(Paths.get(args[0]))) {
			number++;
			values = line.split(",", 2);
			if (values.length != 2) {
				System.err.println("line is not csv format. line=" + (number + 1));
				continue;
			}
			fm = new FileMapping(getExtension(values), getPath(values[0]), getPath(values[1]));
			fm.setFileId("file_" + String.format("%10d", number) + "." + fm.getExtension());
			if (fm.getOldPath() != null) {
				Files.copy(fm.getOldPath(), Paths.get(oldPath.toString(), fm.getFileId()));
			}
			if (fm.getNewPath() != null) {
				Files.copy(fm.getNewPath(), Paths.get(newPath.toString(), fm.getFileId()));
			}
			mappings.add(fm);
		}

		jp.sf.amateras.stepcounter.Main.main(new String[] { "-format=json",
		        "-output=" + tempPath.toString() + "\\old.json", "-encoding=UTF-8", oldPath.toString() });
		jp.sf.amateras.stepcounter.Main.main(new String[] { "-format=json",
		        "-output=" + tempPath.toString() + "\\new.json", "-encoding=UTF-8", newPath.toString() });
		jp.sf.amateras.stepcounter.diffcount.Main
		        .main(new String[] { "-format=text", "-output=" + tempPath.toString() + "\\diff.text",
		                "-encoding=UTF-8", newPath.toString(), oldPath.toString() });

		ObjectMapper mapper = new ObjectMapper();
		Map<String, Count> oldCountMap = new HashMap<String, Count>();
		Map<String, Count> newCountMap = new HashMap<String, Count>();
		for (Count c : mapper.readValue(Files.newInputStream(Paths.get(tempPath.toString() + "\\old.json")),
		        Count[].class)) {
			oldCountMap.put(c.getName(), c);
		}
		for (Count c : mapper.readValue(Files.newInputStream(Paths.get(tempPath.toString() + "\\new.json")),
		        Count[].class)) {
			newCountMap.put(c.getName(), c);
		}
		Map<String, Diff> diffMap = new HashMap<String, Diff>();
		List<String> diffLines = Files.readAllLines(Paths.get(tempPath.toString() + "\\diff.text"));
		Pattern diffPattern = Pattern.compile("^ (.+)\\[(.+)\\] \\+(.+) \\-(.+)$");
		Matcher matcher;
		for (int i = 3; i < diffLines.size(); i++) {
			matcher = diffPattern.matcher(diffLines.get(i));
			if (matcher.find()) {
				diffMap.put(matcher.group(1), new Diff(matcher.group(1), matcher.group(2),
				        Long.parseLong(matcher.group(3)), Long.parseLong(matcher.group(4))));
			}
		}

		List<Object> valList = new ArrayList<Object>();
		Count oldCount, newCount;
		Diff diff;
		System.out.println(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", new Object[] { "old_path", "step",
		        "none", "comment", "total", "new_path", "step", "none", "comment", "total", "diff", "add", "del" }));
		for (FileMapping mapping : mappings) {
			oldCount = oldCountMap.get(mapping.getFileId());
			newCount = newCountMap.get(mapping.getFileId());
			diff = diffMap.get(mapping.getFileId());
			valList.add(Utils.null2default(mapping.getOldPath(), "-"));
			if (oldCount == null) {
				valList.addAll(Arrays.asList(new Object[] { "0", "0", "0", "0" }));
			} else {
				valList.addAll(Arrays.asList(new Object[] { oldCount.getStep(), oldCount.getNone(),
				        oldCount.getComment(), oldCount.getTotal() }));
			}
			valList.add(Utils.null2default(mapping.getNewPath(), "-"));
			if (newCount == null) {
				valList.addAll(Arrays.asList(new Object[] { "0", "0", "0", "0" }));
			} else {
				valList.addAll(Arrays.asList(new Object[] { newCount.getStep(), newCount.getNone(),
				        newCount.getComment(), newCount.getTotal() }));
			}
			valList.addAll(Arrays.asList(new Object[] { diff.getKind(), diff.getAdd(), diff.getDel() }));
			System.out
			        .println(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", valList.toArray(new Object[] {})));
			valList.clear();
		}
	}

	private static Path getPath(String path) {
		if (path != null && !"".equals(path.trim())) {
			return Paths.get(path);
		} else {
			return null;
		}
	}

	private static String getExtension(String... args) {
		String result;
		for (String arg : args) {
			result = Utils.getExtension(arg);
			if (result != null) {
				return result;
			}
		}
		return null;
	}

}
