
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import bean.FileMapping;
import util.Utils;

public class ListMaker {

	private static Mappings MAPPINGS;
	static {
		XmlMapper mapper = new XmlMapper();
		try {
			MAPPINGS = mapper.readValue(ListMaker.class.getResourceAsStream("/mapping.xml"), Mappings.class);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(9);
		}
	}

	public static void main(String[] args) throws Exception {

		if (args.length != 2) {
			System.err.println("Usage: java ListMaker [oldDir] [newDir]");
			System.exit(1);
		}

		Path oldDir = Paths.get(args[0]);
		Path newDir = Paths.get(args[1]);

		final List<FileMapping> result = new ArrayList<FileMapping>();
		compare(oldDir, newDir, new JavaFileVisitor(), result);
		compare(oldDir, newDir, new JspFileVisitor(), result);

		System.out.println("---- File Mapping List ----");
		for (FileMapping fm : result) {
			System.out.println(
			        String.format("%s,%s", Utils.null2empty(fm.getOldPath()), Utils.null2empty(fm.getNewPath())));
		}
	}

	@JacksonXmlRootElement(localName = "mappings")
	private static class Mappings {

		@JacksonXmlProperty(localName = "mapping")
		@JacksonXmlElementWrapper(useWrapping = false)
		private List<Mapping> mappings;

		public List<Mapping> getMappings() {
			return mappings;
		}

		@SuppressWarnings("unused")
		public void setMappings(List<Mapping> mappings) {
			this.mappings = mappings;
		}

	}

	@SuppressWarnings("unused")
	private static class Mapping {

		@JacksonXmlProperty(isAttribute = true)
		private String oldPath;
		@JacksonXmlProperty(isAttribute = true)
		private String newPath;

		public String getOldPath() {
			return oldPath;
		}

		public void setOldPath(String oldPath) {
			this.oldPath = oldPath;
		}

		public String getNewPath() {
			return newPath;
		}

		public void setNewPath(String newPath) {
			this.newPath = newPath;
		}

	}

	private static void compare(Path oldDir, Path newDir, AbstractFileVisitor visitor, List<FileMapping> result)
	        throws IOException {

		Files.walkFileTree(oldDir, visitor);
		final Map<String, List<Path>> oldMap = visitor.getFileMap();
		visitor.clearFileMap();

		Files.walkFileTree(newDir, visitor);
		final Map<String, List<Path>> newMap = visitor.getFileMap();
		visitor.clearFileMap();

		List<Path> oldList, newList;
		for (Mapping mapping : MAPPINGS.getMappings()) {
			if (oldMap.containsKey(mapping.getOldPath()) && newMap.containsKey(mapping.getNewPath())) {
				// mapping by key
				oldList = oldMap.get(mapping.getOldPath());
				newList = newMap.get(mapping.getNewPath());
				if (oldList.size() == newList.size()) {
					for (int i = 0; i < oldList.size(); i++) {
						result.add(new FileMapping(Utils.getExtension(oldList.get(i).getFileName().toString()),
						        oldList.get(i), newList.get(i)));
					}
				} else {
					System.err.println("Failure Mapping b/c list size is not same. oldList=[" + oldList + "], newList=["
					        + newList + "]");
				}
				oldMap.remove(mapping.getOldPath());
				newMap.remove(mapping.getNewPath());
			} else {
				// mapping by path
				String oldKey = null;
				Path oldPath = null;
				for (Entry<String, List<Path>> e : oldMap.entrySet()) {
					for (Path path : e.getValue()) {
						if (path.toString().endsWith(mapping.getOldPath())) {
							oldKey = e.getKey();
							oldPath = path;
							break;
						}
					}
					if (oldKey != null && oldPath != null) {
						break;
					}
				}
				if (oldKey == null) {
					continue;
				}
				oldList = oldMap.get(oldKey);
				if (oldList.size() == 1) {
					oldMap.remove(oldKey);
				} else {
					oldList.remove(oldPath);
				}

				String newKey = null;
				Path newPath = null;
				for (Entry<String, List<Path>> e : newMap.entrySet()) {
					for (Path path : e.getValue()) {
						if (path.toString().endsWith(mapping.getNewPath())) {
							newKey = e.getKey();
							newPath = path;
							break;
						}
					}
					if (newKey != null && newPath != null) {
						break;
					}
				}
				newList = newMap.get(newKey);
				if (newList.size() == 1) {
					newMap.remove(newKey);
				} else {
					newList.remove(newPath);
				}

				result.add(new FileMapping(Utils.getExtension(oldPath.getFileName().toString()), oldPath, newPath));
			}
		}

		final Set<String> keySet = new TreeSet<String>();
		keySet.addAll(oldMap.keySet());
		keySet.addAll(newMap.keySet());

		for (String key : keySet) {
			oldList = oldMap.get(key);
			newList = newMap.get(key);

			if (oldList != null && newList != null) {
				if (oldList.size() == newList.size()) {
					for (int i = 0; i < oldList.size(); i++) {
						result.add(new FileMapping(Utils.getExtension(oldList.get(i).getFileName().toString()),
						        oldList.get(i), newList.get(i)));
					}
				} else {
					System.err.println("Failure Mapping b/c list size is not same. oldList=[" + oldList + "], newList=["
					        + newList + "]");
				}
			} else if (oldList != null) {
				for (int i = 0; i < oldList.size(); i++) {
					result.add(new FileMapping(Utils.getExtension(oldList.get(i).getFileName().toString()),
					        oldList.get(i), null));
				}
			} else if (newList != null) {
				for (int i = 0; i < newList.size(); i++) {
					result.add(new FileMapping(Utils.getExtension(newList.get(i).getFileName().toString()), null,
					        newList.get(i)));
				}
			}

			oldList = oldMap.remove(key);
			newList = newMap.remove(key);

		}

	}

	private static abstract class AbstractFileVisitor implements FileVisitor<Path> {

		private final Map<String, List<Path>> fileMap = new HashMap<String, List<Path>>();

		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		protected void addFile(String key, Path file) {
			if (!fileMap.containsKey(key)) {
				fileMap.put(key, new LinkedList<Path>());
			}
			fileMap.get(key).add(file);
		}

		public Map<String, List<Path>> getFileMap() {
			return new HashMap<String, List<Path>>(fileMap);
		}

		public void clearFileMap() {
			fileMap.clear();
		}

		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {

			final String fileName = file.getFileName().toString();

			if (!fileName.endsWith(getExtension())) {
				return FileVisitResult.CONTINUE;
			}

			addFile(fileName.replace(getExtension(), ""), file);

			return FileVisitResult.CONTINUE;
		}

		protected abstract String getExtension();
	}

	private static class JspFileVisitor extends AbstractFileVisitor {

		@Override
		protected String getExtension() {
			return ".jsp";
		}

	}

	private static class JavaFileVisitor extends AbstractFileVisitor {

		private static final Pattern PACKAGE_REGEX = Pattern.compile("^package (.+);$");

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {

			final String fileName = file.getFileName().toString();

			if (!fileName.endsWith(getExtension())) {
				return FileVisitResult.CONTINUE;
			}

			Matcher matcher;
			boolean match = false;
			for (String line : Files.readAllLines(file)) {
				matcher = PACKAGE_REGEX.matcher(line);
				if (matcher.find()) {
					addFile(matcher.group(1) + "." + fileName.replace(getExtension(), ""), file);
					match = true;
					break;
				}
			}
			if (!match) {
				addFile(fileName.replace(getExtension(), ""), file);
			}

			return FileVisitResult.CONTINUE;
		}

		@Override
		protected String getExtension() {
			return ".java";
		}

	}

}
