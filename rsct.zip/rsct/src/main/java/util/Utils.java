package util;

public class Utils {

	public static String getExtension(String fileName) {
		if (fileName == null)
			return null;
		int point = fileName.lastIndexOf(".");
		if (point != -1) {
			return fileName.substring(point + 1);
		}
		return fileName;
	}

	public static String null2empty(Object val) {
		return val == null ? "" : val.toString();
	}

	public static String null2default(Object val, String defaultValue) {
		return val == null ? defaultValue : val.toString();
	}
}
