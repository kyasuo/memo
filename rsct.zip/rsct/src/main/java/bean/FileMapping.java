package bean;

import java.io.Serializable;
import java.nio.file.Path;

public class FileMapping implements Serializable {

	private static final long serialVersionUID = 8901992278092583819L;
	private String fileId;
	private final String extension;
	private final Path oldPath;
	private final Path newPath;

	public FileMapping(String extension, Path oldPath, Path newPath) {
		super();
		this.extension = extension;
		this.oldPath = oldPath;
		this.newPath = newPath;
	}

	public Path getOldPath() {
		return oldPath;
	}

	public Path getNewPath() {
		return newPath;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getExtension() {
		return extension;
	}

}
