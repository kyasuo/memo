package bean;

import java.io.Serializable;

public class Count implements Serializable {
	private static final long serialVersionUID = -5309440432377250495L;

	private String name;
	private String type;
	private Long step;
	private Long none;
	private Long comment;
	private Long total;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getStep() {
		return step;
	}

	public void setStep(Long step) {
		this.step = step;
	}

	public Long getNone() {
		return none;
	}

	public void setNone(Long none) {
		this.none = none;
	}

	public Long getComment() {
		return comment;
	}

	public void setComment(Long comment) {
		this.comment = comment;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}
}
