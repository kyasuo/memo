package bean;

import java.io.Serializable;

public class Diff implements Serializable {

	private static final long serialVersionUID = 1169918408351003824L;
	private final String name;
	private final String kind;
	private final Long add;
	private final Long del;

	public Diff(String name, String kind, Long add, Long del) {
		super();
		this.name = name;
		this.kind = kind;
		this.add = add;
		this.del = del;
	}

	public String getName() {
		return name;
	}

	public Long getAdd() {
		return add;
	}

	public Long getDel() {
		return del;
	}

	public String getKind() {
		return kind;
	}

}
